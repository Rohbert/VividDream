Super Mario Bros 2.
Vivid Dream v1.1
Author: Rohbert
Release Date: Aug 15, 2025
About:
This hack is a mix of standard and Kaizo level design. 3 Levels. Level 1 being standard, 2 and 3 being much harder Kaizo style levels. This hack was spun off from the SMB2U LDC hosted by SMW Central. I was so inspired by all the levels submitted that I expanded my level and made a 1 world hack. Search youtube for Super Mario Bros. 2 Vivid Dream Walkthrough if you need a hint on completing a section or 2. Good luck! You may use any character for level 1. Levels 2/3 require Mario. Unlimited lives enabled.

Patching:
Use your favorite patching program that can read .bps files. Patch to a Super Mario Bros. 2.nes rom (prg0) CRC32 header of 43507232

Tips:
Hold down on d-pad for 3 or more seconds to charge a high jump that will let you reach high ledges.

Collect 5 cherries to spawn an invincibility star.

Defeat 5 or more enemies to spawn a heart to refill health.

Drop potions where you find them to find a power mushroom.

Hold jump button while landing on a trampoline block to get maximum height (No need to time the button, just hold)

POW blocks can shake items into range.

Bombs can blow up cracked dirt blocks.

Stand on a key or bomb or 1-up and throw a POW block to be lifted off the ground.

While being levitated by a POW block quake, you can phase thru ceilings.

Stop Watches can freeze enemies for several seconds allowing you to use them as platforms.

Throw and ride a turtle shell to cross spiked floors safely.